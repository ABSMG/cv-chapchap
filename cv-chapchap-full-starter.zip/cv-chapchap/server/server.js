import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const PRICE_TZS = 7000;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:5500";
const WEBHOOK_SECRET = process.env.PAYMENT_WEBHOOK_SECRET || "";
const orders = new Map(); // Demo only: use a persistent database before production.

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: FRONTEND_ORIGIN, methods: ["GET", "POST"], allowedHeaders: ["Content-Type", "X-Request-Id"] }));
app.use(express.json({ limit: "20kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false }));

function newId() {
  return crypto.randomUUID();
}
function jsonError(res, status, message) {
  return res.status(status).json({ ok: false, error: message });
}

// No provider URL or payment credentials are invented. Configure an approved provider adapter
// only after the merchant account and official API documentation are available.
function providerConfigured() {
  return Boolean(process.env.PAYMENT_PROVIDER && process.env.PAYMENT_API_BASE_URL &&
    process.env.PAYMENT_API_KEY && process.env.PAYMENT_API_SECRET &&
    process.env.PAYMENT_WEBHOOK_SECRET);
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "cv-chapchap-api", paymentsConfigured: providerConfigured() });
});

app.post("/api/payments/create", (req, res) => {
  if (!providerConfigured()) {
    return jsonError(res, 503, "Malipo hayajaunganishwa. Mmiliki wa tovuti anahitaji kusanidi mtoa huduma rasmi kwanza.");
  }
  // Intentionally fail closed until the provider-specific payment adapter is implemented
  // and tested against that provider's official API. Do not accept client-supplied paid flags.
  return jsonError(res, 501, "Adapter ya mtoa huduma haijatekelezwa. Hakuna malipo yaliyotumwa.");
});

app.get("/api/payments/:id", (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) return jsonError(res, 404, "Oda haijapatikana.");
  return res.json({ ok: true, order: { id: order.id, amount: order.amount, currency: "TZS", status: order.status } });
});

// Provider-specific webhook signatures differ. This endpoint deliberately rejects callbacks
// until a verified adapter is configured. Never mark an order paid from a browser request.
app.post("/api/payments/webhook", (req, res) => {
  if (!WEBHOOK_SECRET) return jsonError(res, 503, "Webhook haijasanidiwa.");
  return jsonError(res, 501, "Uthibitishaji wa webhook wa mtoa huduma haujaunganishwa; oda haijabadilishwa kuwa imelipwa.");
});

app.use((_req, res) => jsonError(res, 404, "Njia haijapatikana."));

app.listen(PORT, () => {
  console.log(`CV ChapChap API listening on port ${PORT}`);
});
